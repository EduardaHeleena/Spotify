import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:myapp/main.dart';

void main() {
  testWidgets('HomeScreen layout test', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const MyApp());

    // Verify that the title "Boa noite" is displayed.
    expect(find.text('Boa noite'), findsOneWidget);

    // Verify that the action icons are present.
    expect(find.byIcon(Icons.notifications), findsOneWidget);
    expect(find.byIcon(Icons.history), findsOneWidget);
    expect(find.byIcon(Icons.settings), findsOneWidget);

    // Verify that the section titles are displayed.
    expect(find.text('Recente'), findsOneWidget);
    expect(find.text('Lançamento'), findsOneWidget);
    expect(find.text('Faixas Recomendadas'), findsOneWidget);

    // Verify that at least one album is displayed in the "Recente" section.
    expect(find.byType(GridView), findsWidgets);

    // Verify the mini player is present.
    expect(find.text('Me Curar de Mim'), findsOneWidget);
    expect(find.text('Flaira Ferro'), findsOneWidget);
    expect(find.byIcon(Icons.pause_circle_filled), findsOneWidget);

    // Verify that the bottom navigation icons are present.
    expect(find.byIcon(Icons.home), findsOneWidget);
    expect(find.byIcon(Icons.search), findsOneWidget);
    expect(find.byIcon(Icons.library_music), findsOneWidget);
  });
}
