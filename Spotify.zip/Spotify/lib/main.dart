import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  final List<Map<String, String>> albums = [
    {'title': 'Eduarda', 'image': 'images/eduarda.jpg'},
    {'title': 'Black To Black', 'image': 'images/black.jpg'},
    {'title': 'Clássicas Jazz', 'image': 'images/jazz.png'},
    {'title': 'Top 50 Global', 'image': 'images/top50.jpeg'},
    {'title': 'Mix 2000', 'image': 'images/mix2000.jpeg'},
    {'title': 'Mix Bruno Mars', 'image': 'images/bruninho.jpg'},
  ];

  final List<Map<String, String>> recommendedTracks = [
    {'image': 'images/faixa1.jpg'},
    {'image': 'images/faixa2.jpg'},
    {'image': 'images/faixa3.jpg'},
    {'image': 'images/faixa4.jpeg'},
  ];

  HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        title: const Text(
          'Boa noite',
          style: TextStyle(color: Colors.white, fontSize: 24),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications, color: Colors.white),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.history, color: Colors.white),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.settings, color: Colors.white),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Recent Section
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: const Text(
                'Recentes',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold),
              ),
            ),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 8,
                crossAxisSpacing: 8,
                childAspectRatio: 3,
              ),
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: albums.length,
              itemBuilder: (context, index) {
                return Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.grey[800],
                  ),
                  child: Row(
                    children: [
                      Container(
                        margin: const EdgeInsets.all(8.0),
                        width: 60,
                        height: 60,
                        child: Image.asset(albums[index]['image']!,
                            fit: BoxFit.cover),
                      ),
                      Flexible(
                        child: Text(
                          albums[index]['title']!,
                          style: const TextStyle(color: Colors.white),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),

            // Lançamento Section
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: const Text(
                'Lançamento',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.grey[800],
                ),
                child: Row(
                  children: [
                    Container(
                      margin: const EdgeInsets.all(8.0),
                      width: 80,
                      height: 80,
                      child: Image.asset('images/apt.jpg', fit: BoxFit.cover),
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'APT. Rosé & Bruno Mars',
                            style: TextStyle(color: Colors.white, fontSize: 16),
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              IconButton(
                                icon: const Icon(Icons.favorite_border,
                                    color: Colors.white),
                                onPressed: () {},
                              ),
                              IconButton(
                                icon: const Icon(Icons.play_circle_fill,
                                    color: Colors.white),
                                onPressed: () {},
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Recommended Tracks Section
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: const Text(
                'Faixas Recomendadas',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold),
              ),
            ),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                mainAxisSpacing: 8,
                crossAxisSpacing: 8,
              ),
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: recommendedTracks.length,
              itemBuilder: (context, index) {
                return Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.grey[800],
                  ),
                  child: Image.asset(recommendedTracks[index]['image']!,
                      fit: BoxFit.cover),
                );
              },
            ),
          ],
        ),
      ),

      // Mini Player
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            color: Colors.grey[900],
            child: ListTile(
              leading: Image.asset('images/player.jpg'),
              title: const Text(
                'Dont look back in anger',
                style: TextStyle(color: Colors.white),
              ),
              subtitle: const Text(
                'Oasis',
                style: TextStyle(color: Colors.grey),
              ),
              trailing: IconButton(
                icon:
                    const Icon(Icons.pause_circle_filled, color: Colors.white),
                onPressed: () {},
              ),
            ),
          ),
          BottomNavigationBar(
            backgroundColor: Colors.black,
            items: const [
              BottomNavigationBarItem(
                icon: Icon(Icons.home, color: Colors.white),
                label: '',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.search, color: Colors.white),
                label: '',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.library_music, color: Colors.white),
                label: '',
              ),
            ],
          ),
        ],
      ),
    );
  }
}
